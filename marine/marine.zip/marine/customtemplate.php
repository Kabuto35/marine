<?php /* Template Name: Custom template name */ ?>

<?php get_header() ?>

<header></header>

<main></main>

<?php get_footer() ?>
