<?php get_header() ?>

<header></header>

<main>
    <h1>Error 404</h1>
</main>

<?php get_footer() ?>